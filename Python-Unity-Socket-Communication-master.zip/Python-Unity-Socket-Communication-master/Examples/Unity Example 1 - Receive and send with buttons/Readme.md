This example receives data from Python3 and displays in app.
A button can be clicked to send a string to Python3 from Unity
Note quit button will not do much unless you build the application.
Note: I use Pycharm as my Python IDE

Steps
1. Create an empty 3D unity project
2. Drag the unitypackage into your assets folder directly in Unity
3. Import all files
4. You should be asked to download TMPro. 
5. Download the essentials only
6. Run the server.py (using Pycharm in my case) Python Script.
7. Run Unity Editor or built app
8. You should see the text at the top of the unity app update each second
9. On clicking the "Send" button, a string should be sent to Python3 and be displayed there
